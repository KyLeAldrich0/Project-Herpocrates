/**
 * Harpocrates - Silent local PDF reader and assistant
 * Manifest V3 Background Service Worker
 * Supports Direct PDFs, Google Classroom / Drive Previews (Zero Download),
 * Google Gemini API (gemini-3.8-flash Free Tier) & OpenRouter API.
 */

// Safe chunked Base64 encoder for ArrayBuffer
function arrayBufferToBase64(buffer) {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const len = bytes.byteLength;
  const chunkSize = 0x8000; // 32KB chunks
  for (let i = 0; i < len; i += chunkSize) {
    const chunk = bytes.subarray(i, Math.min(i + chunkSize, len));
    binary += String.fromCharCode.apply(null, chunk);
  }
  return btoa(binary);
}

// Check if a URL directly points to a PDF document
function isPdfUrl(url) {
  if (!url) return false;
  try {
    const parsed = new URL(url);
    const cleanPath = parsed.pathname.toLowerCase().split('#')[0].split('?')[0];
    return cleanPath.endsWith('.pdf');
  } catch {
    const cleanUrl = url.toLowerCase().split('#')[0].split('?')[0];
    return cleanUrl.endsWith('.pdf');
  }
}

// Extract filename from URL
function extractFilename(url) {
  try {
    const parsed = new URL(url);
    const pathname = parsed.pathname;
    const parts = pathname.split('/');
    const lastPart = parts[parts.length - 1];
    const decoded = decodeURIComponent(lastPart);
    return decoded || "document.pdf";
  } catch {
    return "document.pdf";
  }
}

// In-page UI function injected into the target tab
function renderStealthUI(status, content) {
  const HOST_ID = 'harpocrates-stealth-host';
  let host = document.getElementById(HOST_ID);

  if (!host) {
    host = document.createElement('div');
    host.id = HOST_ID;

    // Invisible 60px x 60px trigger zone fixed to bottom-left corner
    Object.assign(host.style, {
      position: 'fixed',
      bottom: '0px',
      left: '0px',
      width: '60px',
      height: '60px',
      zIndex: '2147483647',
      background: 'transparent',
      pointerEvents: 'auto',
      userSelect: 'none',
      transition: 'width 0.15s ease, height 0.15s ease',
      display: 'block',
      margin: '0',
      padding: '0',
      border: 'none',
      boxSizing: 'border-box'
    });

    const shadow = host.attachShadow({ mode: 'open' });

    // Injected styles inside Shadow DOM
    const style = document.createElement('style');
    style.textContent = `
      :host {
        all: initial;
      }
      *, *::before, *::after {
        box-sizing: border-box;
      }
      .trigger-container {
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: transparent;
      }
      /* Tiny 4px x 4px low-opacity status dot */
      .status-dot {
        position: absolute;
        bottom: 4px;
        left: 4px;
        width: 4px;
        height: 4px;
        border-radius: 50%;
        pointer-events: none;
        opacity: 0.25;
        transition: background-color 0.3s ease, opacity 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
        background-color: #64748b;
      }
      .status-dot.loading {
        background-color: #f59e0b;
        opacity: 0.65;
        box-shadow: 0 0 6px rgba(245, 158, 11, 0.6);
        animation: harpocrates-pulse 1.8s infinite ease-in-out;
      }
      .status-dot.ready {
        background-color: #10b981;
        opacity: 0.65;
        box-shadow: 0 0 6px rgba(16, 185, 129, 0.5);
        animation: none;
      }
      .status-dot.error {
        background-color: #ef4444;
        opacity: 0.7;
        box-shadow: 0 0 6px rgba(239, 68, 68, 0.5);
        animation: none;
      }
      @keyframes harpocrates-pulse {
        0%, 100% {
          transform: scale(1);
          opacity: 0.3;
        }
        50% {
          transform: scale(1.7);
          opacity: 0.85;
        }
      }
      /* Dark, semi-transparent floating answer box */
      .answer-box {
        position: absolute;
        bottom: 12px;
        left: 12px;
        width: 350px;
        max-width: 360px;
        max-height: 320px;
        overflow-y: auto;
        opacity: 0;
        pointer-events: none;
        transform: translateY(4px);
        transition: opacity 0.15s ease, transform 0.15s ease;
        background: rgba(15, 17, 23, 0.95);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 8px;
        box-shadow: 0 12px 30px -4px rgba(0, 0, 0, 0.65), 0 4px 12px -2px rgba(0, 0, 0, 0.45);
        color: #f1f5f9;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        font-size: 12px;
        line-height: 1.55;
        padding: 12px 14px;
        user-select: text;
        scrollbar-width: thin;
        scrollbar-color: rgba(255, 255, 255, 0.2) transparent;
      }
      .answer-box::-webkit-scrollbar {
        width: 4px;
      }
      .answer-box::-webkit-scrollbar-track {
        background: transparent;
      }
      .answer-box::-webkit-scrollbar-thumb {
        background: rgba(255, 255, 255, 0.2);
        border-radius: 2px;
      }
      .answer-box::-webkit-scrollbar-thumb:hover {
        background: rgba(255, 255, 255, 0.4);
      }
      .box-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding-bottom: 7px;
        margin-bottom: 8px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.08);
      }
      .box-title {
        font-size: 11px;
        font-weight: 600;
        letter-spacing: 0.06em;
        text-transform: uppercase;
        color: #94a3b8;
      }
      .box-status-tag {
        font-size: 10px;
        padding: 1px 6px;
        border-radius: 4px;
        font-weight: 500;
      }
      .box-status-tag.loading {
        background: rgba(245, 158, 11, 0.15);
        color: #f59e0b;
        border: 1px solid rgba(245, 158, 11, 0.25);
      }
      .box-status-tag.ready {
        background: rgba(16, 185, 129, 0.15);
        color: #34d399;
        border: 1px solid rgba(16, 185, 129, 0.25);
      }
      .box-status-tag.error {
        background: rgba(239, 68, 68, 0.15);
        color: #f87171;
        border: 1px solid rgba(239, 68, 68, 0.25);
      }
      .box-content {
        white-space: pre-wrap;
        word-break: break-word;
        color: #cbd5e1;
        font-size: 12px;
        max-height: 250px;
      }
    `;

    shadow.appendChild(style);

    const trigger = document.createElement('div');
    trigger.className = 'trigger-container';

    const dot = document.createElement('div');
    dot.className = 'status-dot';
    dot.id = 'status-dot';
    trigger.appendChild(dot);

    const box = document.createElement('div');
    box.className = 'answer-box';
    box.id = 'answer-box';

    const header = document.createElement('div');
    header.className = 'box-header';

    const title = document.createElement('span');
    title.className = 'box-title';
    title.textContent = 'Harpocrates';
    header.appendChild(title);

    const statusTag = document.createElement('span');
    statusTag.className = 'box-status-tag';
    statusTag.id = 'status-tag';
    statusTag.textContent = 'Idle';
    header.appendChild(statusTag);

    const contentDiv = document.createElement('div');
    contentDiv.className = 'box-content';
    contentDiv.id = 'box-content';

    box.appendChild(header);
    box.appendChild(contentDiv);
    trigger.appendChild(box);

    shadow.appendChild(trigger);

    // Pointer Behavior:
    // On mouseenter: expand hit area to 380px x 340px and set opacity: 1, pointer-events: auto
    // On mouseleave: immediately reset to opacity: 0, pointer-events: none and collapse hit area to 60px x 60px
    host.addEventListener('mouseenter', () => {
      host.style.width = '380px';
      host.style.height = '340px';
      box.style.opacity = '1';
      box.style.pointerEvents = 'auto';
      box.style.transform = 'translateY(0)';
    });

    host.addEventListener('mouseleave', () => {
      host.style.width = '60px';
      host.style.height = '60px';
      box.style.opacity = '0';
      box.style.pointerEvents = 'none';
      box.style.transform = 'translateY(4px)';
    });

    const targetContainer = document.body || document.documentElement;
    if (targetContainer) {
      targetContainer.appendChild(host);
    }
  }

  // Update status and content inside the Shadow DOM
  const shadow = host.shadowRoot;
  if (!shadow) return;

  const dot = shadow.getElementById('status-dot');
  const tag = shadow.getElementById('status-tag');
  const contentEl = shadow.getElementById('box-content');

  if (dot && tag && contentEl) {
    dot.className = `status-dot ${status}`;
    tag.className = `box-status-tag ${status}`;

    if (status === 'loading') {
      tag.textContent = 'Analyzing...';
    } else if (status === 'ready') {
      tag.textContent = 'Answers Ready';
    } else if (status === 'error') {
      tag.textContent = 'Error';
    } else {
      tag.textContent = 'Idle';
    }

    contentEl.textContent = content || '';
  }
}

// Safely execute the UI script in the tab
async function updateTabUI(tabId, status, content) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: renderStealthUI,
      args: [status, content]
    });
  } catch (err) {
    console.error("Harpocrates: Unable to inject script into tab:", err);
  }
}

// In-page document extractor (runs inside Google Classroom / Drive / web viewer)
// Extracts the PDF directly in-memory via Google Drive file IDs or text layers WITHOUT downloading!
async function inPageDocumentExtractor() {
  function bufferToBase64(buffer) {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    const chunkSize = 0x8000;
    for (let i = 0; i < len; i += chunkSize) {
      const chunk = bytes.subarray(i, Math.min(i + chunkSize, len));
      binary += String.fromCharCode.apply(null, chunk);
    }
    return btoa(binary);
  }

  function isPdfBuffer(buffer) {
    if (!buffer || buffer.byteLength < 4) return false;
    const bytes = new Uint8Array(buffer, 0, 4);
    return bytes[0] === 0x25 && bytes[1] === 0x50 && bytes[2] === 0x44 && bytes[3] === 0x46; // %PDF
  }

  // Strategy 1: Find Google Drive File IDs in Google Classroom or Drive Viewer
  const driveFileIds = [];

  // 1a. URL match if on drive.google.com/file/d/...
  const urlMatch = window.location.href.match(/\/file\/d\/([a-zA-Z0-9_-]{20,})/);
  if (urlMatch && urlMatch[1]) {
    driveFileIds.push(urlMatch[1]);
  }

  // 1b. Inspect active modal/dialogs (like the preview dialog in Classroom)
  const modals = document.querySelectorAll('[role="dialog"], [aria-modal="true"], div[tabindex="-1"]');
  for (const modal of modals) {
    const links = modal.querySelectorAll('a[href*="drive.google.com"], iframe[src*="drive.google.com"], [data-url*="drive.google.com"]');
    for (const el of links) {
      const target = el.href || el.src || el.getAttribute('data-url') || '';
      const m = target.match(/\/(?:file\/d|open\?id=)([a-zA-Z0-9_-]{20,})/);
      if (m && m[1]) driveFileIds.push(m[1]);
    }
  }

  // 1c. Inspect all anchors or iframes referencing drive.google.com
  const allElements = document.querySelectorAll('a[href*="drive.google.com"], iframe[src*="drive.google.com"], [data-drive-id], [data-item-id]');
  for (const el of allElements) {
    const target = el.href || el.src || el.getAttribute('data-drive-id') || el.getAttribute('data-item-id') || '';
    const m = target.match(/\/(?:file\/d|open\?id=)([a-zA-Z0-9_-]{20,})/) || target.match(/^([a-zA-Z0-9_-]{25,})$/);
    if (m && m[1]) driveFileIds.push(m[1]);
  }

  // 1d. Regex scan in page HTML for drive URLs
  const htmlMatches = document.documentElement.innerHTML.match(/https?:\/\/drive\.google\.com\/(?:file\/d\/|open\?id=)([a-zA-Z0-9_-]{20,})/g);
  if (htmlMatches) {
    for (const mStr of htmlMatches) {
      const m = mStr.match(/([a-zA-Z0-9_-]{20,})$/);
      if (m && m[1]) driveFileIds.push(m[1]);
    }
  }

  const uniqueFileIds = [...new Set(driveFileIds)];

  // Try fetching the raw PDF directly in-memory using the user's active session
  for (const fileId of uniqueFileIds) {
    const endpoints = [
      `https://drive.google.com/uc?export=download&id=${fileId}`,
      `https://docs.google.com/uc?export=download&id=${fileId}`,
      `https://drive.google.com/uc?export=download&confirm=t&id=${fileId}`
    ];
    for (const ep of endpoints) {
      try {
        const resp = await fetch(ep, { credentials: 'include' });
        if (resp.ok) {
          const buf = await resp.arrayBuffer();
          if (isPdfBuffer(buf)) {
            return {
              success: true,
              type: 'pdf',
              base64Pdf: bufferToBase64(buf),
              fileName: 'classroom_document.pdf'
            };
          }
        }
      } catch (_) {}
    }
  }

  // Strategy 2: Check for embed, object, or blob URLs
  const embeds = document.querySelectorAll('embed[type="application/pdf"], object[type="application/pdf"], iframe[src*="blob:"], iframe[src*=".pdf"]');
  for (const el of embeds) {
    const src = el.src || el.data;
    if (src) {
      try {
        const resp = await fetch(src, { credentials: 'include' });
        if (resp.ok) {
          const buf = await resp.arrayBuffer();
          if (isPdfBuffer(buf)) {
            return {
              success: true,
              type: 'pdf',
              base64Pdf: bufferToBase64(buf),
              fileName: 'embedded_document.pdf'
            };
          }
        }
      } catch (_) {}
    }
  }

  // Strategy 3: In-page DOM Text Extraction
  // If direct PDF binary is protected, extract text directly from the rendered viewer pages
  const textContainers = document.querySelectorAll(
    '.drive-viewer-page, .kix-page, [role="document"], [aria-label*="Page"], [class*="viewer-page"], [class*="drive-viewer"]'
  );

  let extractedText = '';
  if (textContainers.length > 0) {
    const parts = [];
    textContainers.forEach((el, idx) => {
      const t = el.innerText ? el.innerText.trim() : '';
      if (t.length > 20) {
        parts.push(`=== PAGE ${idx + 1} ===\n${t}`);
      }
    });
    extractedText = parts.join('\n\n');
  }

  if (!extractedText || extractedText.length < 50) {
    // If specific containers didn't yield enough, inspect the active modal
    const activeModal = document.querySelector('[role="dialog"], [aria-modal="true"]');
    if (activeModal && activeModal.innerText && activeModal.innerText.length > 80) {
      extractedText = activeModal.innerText.trim();
    }
  }

  if (extractedText && extractedText.length > 50) {
    return {
      success: true,
      type: 'text',
      text: extractedText,
      fileName: 'classroom_page_text.txt'
    };
  }

  return { success: false };
}

// Query Google Gemini API (Free tier via Google AI Studio)
async function callGeminiApi({ apiKey, modelId, base64Pdf, documentText }) {
  let model = modelId ? modelId.trim() : "gemini-3.8-flash";
  if (model.includes("2.5") || model.includes("1.5") || model === "gemini-flash") {
    model = "gemini-3.8-flash";
  }

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;

  const parts = [];
  if (base64Pdf) {
    parts.push({
      text: "Analyze this PDF. Identify every question, problem, or prompt in the document and provide concise, accurate answers numbered clearly (e.g., 1. Answer, 2. Answer). Do not include filler text."
    });
    parts.push({
      inlineData: {
        mimeType: "application/pdf",
        data: base64Pdf
      }
    });
  } else if (documentText) {
    parts.push({
      text: "Analyze this document text. Identify every question, problem, or prompt in the document and provide concise, accurate answers numbered clearly (e.g., 1. Answer, 2. Answer). Do not include filler text.\n\nDOCUMENT CONTENT:\n" + documentText
    });
  } else {
    throw new Error("No PDF binary or text content provided for analysis.");
  }

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-goog-api-key": apiKey
    },
    body: JSON.stringify({ contents: [{ parts }] })
  });

  if (!response.ok) {
    let errMessage = `Gemini API HTTP ${response.status}`;
    try {
      const errJson = await response.json();
      if (errJson?.error?.message) {
        errMessage = errJson.error.message;
      }
    } catch (_) {
      const rawText = await response.text();
      if (rawText) errMessage += `: ${rawText.slice(0, 150)}`;
    }
    throw new Error(errMessage);
  }

  const data = await response.json();
  const candidate = data.candidates?.[0];
  const responseParts = candidate?.content?.parts;
  const answer = responseParts?.map(p => p.text).filter(Boolean).join('\n');

  if (!answer) {
    throw new Error("No answer generated by Gemini model response.");
  }

  return answer.trim();
}

// Query OpenRouter API
async function callOpenRouterApi({ apiKey, modelId, base64Pdf, fileName, documentText }) {
  const model = modelId || "google/gemini-2.5-flash-lite";
  let content = [];

  if (base64Pdf) {
    content = [
      {
        type: "text",
        text: "Analyze this PDF. Identify every question, problem, or prompt in the document and provide concise, accurate answers numbered clearly (e.g., 1. Answer, 2. Answer). Do not include filler text."
      },
      {
        type: "file",
        file: {
          filename: fileName,
          file_data: "data:application/pdf;base64," + base64Pdf
        }
      }
    ];
  } else if (documentText) {
    content = [
      {
        type: "text",
        text: "Analyze this document text. Identify every question, problem, or prompt in the document and provide concise, accurate answers numbered clearly (e.g., 1. Answer, 2. Answer). Do not include filler text.\n\nDOCUMENT CONTENT:\n" + documentText
      }
    ];
  }

  const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json",
      "X-Title": "Harpocrates"
    },
    body: JSON.stringify({
      model: model,
      messages: [{ role: "user", content: content }]
    })
  });

  if (!response.ok) {
    let errorDetail = `OpenRouter API HTTP ${response.status}`;
    try {
      const errorJson = await response.json();
      if (errorJson?.error?.message) {
        errorDetail = errorJson.error.message;
      }
    } catch (_) {
      const rawText = await response.text();
      if (rawText) {
        errorDetail += `: ${rawText.slice(0, 150)}`;
      }
    }
    throw new Error(errorDetail);
  }

  const responseData = await response.json();
  const answerContent = responseData.choices?.[0]?.message?.content;

  if (!answerContent) {
    throw new Error("No answer content received from model response.");
  }

  return answerContent.trim();
}

// Core execution handler when user presses the shortcut
async function handleSolvePdf() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id || !tab.url) return;

  // Retrieve API key, model ID and provider from storage
  const storageData = await chrome.storage.local.get(["apiKey", "modelId", "provider"]);
  const apiKey = storageData.apiKey ? storageData.apiKey.trim() : "";
  let provider = storageData.provider || "gemini";

  // Auto-detect provider if recognizable
  if (apiKey.startsWith("AIza")) {
    provider = "gemini";
  } else if (apiKey.startsWith("sk-or-")) {
    provider = "openrouter";
  }

  // Check if API key is configured
  if (!apiKey) {
    await updateTabUI(
      tab.id,
      "error",
      "API Key is missing.\n\nPlease open chrome://extensions -> Harpocrates -> Details -> Extension options to enter your free Google Gemini API Key or OpenRouter key."
    );
    return;
  }

  let modelId = (storageData.modelId && storageData.modelId.trim()) 
    ? storageData.modelId.trim() 
    : (provider === "gemini" ? "gemini-3.8-flash" : "google/gemini-2.5-flash-lite");

  if (provider === "gemini" && (modelId.includes("2.5") || modelId.includes("1.5"))) {
    modelId = "gemini-3.8-flash";
    chrome.storage.local.set({ modelId: "gemini-3.8-flash" }).catch(() => {});
  }

  // Display initial loading state
  const providerLabel = provider === "gemini" ? "Google Gemini (gemini-3.8-flash)" : "OpenRouter";
  await updateTabUI(
    tab.id,
    "loading",
    `Reading document and analyzing with ${providerLabel}...`
  );

  let base64Pdf = null;
  let documentText = null;
  let fileName = "document.pdf";

  // Scenario 1: Direct PDF URL (file:/// or web .pdf)
  if (isPdfUrl(tab.url)) {
    fileName = extractFilename(tab.url);
    try {
      const fileResponse = await fetch(tab.url);
      if (!fileResponse.ok) {
        throw new Error(`HTTP ${fileResponse.status} ${fileResponse.statusText}`);
      }
      const buffer = await fileResponse.arrayBuffer();
      base64Pdf = arrayBufferToBase64(buffer);
    } catch (err) {
      let message = `Failed to fetch PDF: ${err.message || err}`;
      if (tab.url.startsWith("file://")) {
        message += "\n\nNote: For local files (file:///), you must enable 'Allow access to file URLs' in chrome://extensions -> Harpocrates -> Details.";
      }
      await updateTabUI(tab.id, "error", message);
      return;
    }
  } else {
    // Scenario 2: Web Preview (Google Classroom, Google Drive, or embedded document)
    // Run in-page extractor directly inside the tab
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: inPageDocumentExtractor
      });

      const extracted = results?.[0]?.result;

      if (extracted && extracted.success) {
        if (extracted.type === 'pdf' && extracted.base64Pdf) {
          base64Pdf = extracted.base64Pdf;
          fileName = extracted.fileName || "classroom_document.pdf";
        } else if (extracted.type === 'text' && extracted.text) {
          documentText = extracted.text;
          fileName = extracted.fileName || "classroom_text.txt";
        }
      } else {
        throw new Error("No PDF or readable text detected in current page.");
      }
    } catch (extractErr) {
      await updateTabUI(
        tab.id,
        "error",
        `Could not extract document from this page: ${extractErr.message || extractErr}\n\nTip: Click inside the PDF preview area once and press Ctrl+Shift+X again.`
      );
      return;
    }
  }

  // Send request to Gemini or OpenRouter
  try {
    let answerContent = "";
    if (provider === "gemini") {
      answerContent = await callGeminiApi({ apiKey, modelId, base64Pdf, documentText });
    } else {
      answerContent = await callOpenRouterApi({ apiKey, modelId, base64Pdf, fileName, documentText });
    }

    // Deliver ready answers to the hover UI
    await updateTabUI(tab.id, "ready", answerContent);
  } catch (apiErr) {
    await updateTabUI(
      tab.id,
      "error",
      `API Error: ${apiErr.message || apiErr}`
    );
  }
}

// Register shortcut command listener
chrome.commands.onCommand.addListener((command) => {
  if (command === "solve-pdf") {
    handleSolvePdf().catch((err) => {
      console.error("Harpocrates: Unexpected command error:", err);
    });
  }
});
