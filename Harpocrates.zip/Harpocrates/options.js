/**
 * Harpocrates - Settings Controller
 * Supports Google Gemini API (Free tier) and OpenRouter
 */

document.addEventListener('DOMContentLoaded', async () => {
  const form = document.getElementById('settings-form');
  const apiKeyInput = document.getElementById('api-key');
  const apiKeyLabel = document.getElementById('api-key-label');
  const keyHint = document.getElementById('key-hint');
  const modelIdInput = document.getElementById('model-id');
  const presetsContainer = document.getElementById('presets-container');
  const toggleKeyBtn = document.getElementById('toggle-key-visibility');
  const eyeIcon = document.getElementById('eye-icon');
  const statusMsg = document.getElementById('status-message');
  const tabButtons = document.querySelectorAll('.tab-btn');
  const providerHint = document.getElementById('provider-hint');

  let currentProvider = 'gemini';

  const PROVIDER_CONFIGS = {
    gemini: {
      keyLabel: 'Google Gemini API Key',
      keyPlaceholder: 'AIzaSy...',
      keyHintHtml: 'Get your free Gemini API key at <a href="https://aistudio.google.com/apikey" target="_blank" rel="noreferrer">aistudio.google.com/apikey</a>. No credit card or minimum balance needed!',
      providerHintHtml: 'Google AI Studio provides a free tier for Gemini models with <strong>$0 deposit required</strong>.',
      defaultModel: 'gemini-3.8-flash',
      presets: [
        { id: 'gemini-3.8-flash', label: 'gemini-3.8-flash (Recommended)' },
        { id: 'gemini-3.6-flash', label: 'gemini-3.6-flash' },
        { id: 'gemini-3-flash-preview', label: 'gemini-3-flash-preview' }
      ]
    },
    openrouter: {
      keyLabel: 'OpenRouter API Key',
      keyPlaceholder: 'sk-or-v1-...',
      keyHintHtml: 'Obtain key at <a href="https://openrouter.ai/keys" target="_blank" rel="noreferrer">openrouter.ai/keys</a>. Requires <strong>$0.50 minimum balance</strong> for file attachments.',
      providerHintHtml: 'OpenRouter provides unified access to models, but requires <strong>$0.50 minimum balance</strong> for PDF files.',
      defaultModel: 'google/gemini-2.5-flash-lite',
      presets: [
        { id: 'google/gemini-2.5-flash-lite', label: 'gemini-2.5-flash-lite' },
        { id: 'google/gemini-2.5-pro', label: 'gemini-2.5-pro' },
        { id: 'anthropic/claude-3.5-sonnet', label: 'claude-3.5-sonnet' },
        { id: 'openai/gpt-4o-mini', label: 'gpt-4o-mini' }
      ]
    }
  };

  // Render presets for active provider
  function renderPresets(provider, currentModel) {
    const config = PROVIDER_CONFIGS[provider];
    presetsContainer.innerHTML = '<span class="preset-label">Quick select:</span>';

    config.presets.forEach(p => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `preset-btn ${p.id === currentModel ? 'active' : ''}`;
      btn.textContent = p.label;
      btn.setAttribute('data-model', p.id);
      btn.addEventListener('click', () => {
        modelIdInput.value = p.id;
        updateActivePresetHighlight(p.id);
      });
      presetsContainer.appendChild(btn);
    });
  }

  function updateActivePresetHighlight(selectedModel) {
    const buttons = presetsContainer.querySelectorAll('.preset-btn');
    buttons.forEach(b => {
      if (b.getAttribute('data-model') === selectedModel) {
        b.classList.add('active');
      } else {
        b.classList.remove('active');
      }
    });
  }

  // Switch Provider UI
  function switchProvider(provider, forceModel = null) {
    currentProvider = provider;
    const config = PROVIDER_CONFIGS[provider];

    // Update Tabs
    tabButtons.forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-provider') === provider);
    });

    // Update Input Labels & Placeholders
    apiKeyLabel.textContent = config.keyLabel;
    apiKeyInput.placeholder = config.keyPlaceholder;
    keyHint.innerHTML = config.keyHintHtml;
    providerHint.innerHTML = config.providerHintHtml;

    // Update Model ID (auto-upgrade old 2.5/1.5 models for Gemini)
    let modelToUse = forceModel || config.defaultModel;
    if (provider === 'gemini' && (modelToUse.includes('2.5') || modelToUse.includes('1.5'))) {
      modelToUse = config.defaultModel;
    }

    modelIdInput.value = modelToUse;
    modelIdInput.placeholder = config.defaultModel;

    renderPresets(provider, modelToUse);
  }

  // Tab click listeners
  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const provider = btn.getAttribute('data-provider');
      if (provider !== currentProvider) {
        switchProvider(provider);
      }
    });
  });

  // Auto-detect provider if user pastes a recognizable key prefix
  apiKeyInput.addEventListener('input', () => {
    const val = apiKeyInput.value.trim();
    if (val.startsWith('AIza') && currentProvider !== 'gemini') {
      switchProvider('gemini');
    } else if (val.startsWith('sk-or-') && currentProvider !== 'openrouter') {
      switchProvider('openrouter');
    }
  });

  modelIdInput.addEventListener('input', () => {
    updateActivePresetHighlight(modelIdInput.value.trim());
  });

  // Load existing values from chrome.storage.local
  try {
    const data = await chrome.storage.local.get(['apiKey', 'modelId', 'provider']);
    let initialProvider = data.provider || 'gemini';

    if (data.apiKey) {
      apiKeyInput.value = data.apiKey;
      if (data.apiKey.startsWith('AIza')) {
        initialProvider = 'gemini';
      } else if (data.apiKey.startsWith('sk-or-')) {
        initialProvider = 'openrouter';
      }
    }

    let initialModel = data.modelId || PROVIDER_CONFIGS[initialProvider].defaultModel;
    if (initialProvider === 'gemini' && (initialModel.includes('2.5') || initialModel.includes('1.5'))) {
      initialModel = 'gemini-3.8-flash';
    }

    switchProvider(initialProvider, initialModel);
  } catch (err) {
    console.error('Failed to load storage data:', err);
    switchProvider('gemini');
  }

  // Toggle API Key visibility
  toggleKeyBtn.addEventListener('click', () => {
    const isPassword = apiKeyInput.type === 'password';
    apiKeyInput.type = isPassword ? 'text' : 'password';

    if (isPassword) {
      eyeIcon.innerHTML = `
        <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path>
        <line x1="1" y1="1" x2="23" y2="23"></line>
      `;
    } else {
      eyeIcon.innerHTML = `
        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
        <circle cx="12" cy="12" r="3"></circle>
      `;
    }
  });

  // Form submission: save to chrome.storage.local
  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const apiKey = apiKeyInput.value.trim();
    let modelId = modelIdInput.value.trim();
    const config = PROVIDER_CONFIGS[currentProvider];

    if (!modelId) {
      modelId = config.defaultModel;
      modelIdInput.value = modelId;
    }

    try {
      await chrome.storage.local.set({
        provider: currentProvider,
        apiKey: apiKey,
        modelId: modelId
      });

      showStatus(`Settings saved! Using ${currentProvider === 'gemini' ? 'Google Gemini (' + modelId + ')' : 'OpenRouter'}.`, 'success');
      updateActivePresetHighlight(modelId);
    } catch (err) {
      showStatus(`Failed to save: ${err.message || err}`, 'error');
    }
  });

  let statusTimeout = null;
  function showStatus(message, type) {
    if (statusTimeout) {
      clearTimeout(statusTimeout);
    }

    statusMsg.textContent = message;
    statusMsg.className = `status-msg show ${type}`;

    statusTimeout = setTimeout(() => {
      statusMsg.className = 'status-msg';
    }, 3000);
  }
});
