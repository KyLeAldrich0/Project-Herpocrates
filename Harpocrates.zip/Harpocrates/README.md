# Harpocrates

> *Silent local PDF reader and question-answering assistant powered by Google Gemini and OpenRouter.*

**Harpocrates** (named after the Hellenistic deity of silence, secrets, and confidential wisdom) is a stealth, production-grade Chrome Extension (Manifest V3) designed to analyze documents and question prompts directly inside Chrome without disrupting your screen or leaving visible traces.

---

## Key Features & Architecture

- **Stealth by Design**:
  - **No Toolbar Icon**: The extension deliberately omits the `action` manifest key. It does not occupy space on your Chrome toolbar.
  - **Invisible Hit Area**: A `60px × 60px` transparent trigger zone anchored at the bottom-left corner (`bottom: 0; left: 0`).
  - **Micro Status Indicator**: A tiny `4px × 4px` low-opacity dot at `bottom: 4px; left: 4px` that transitions between:
    - **Faint amber (pulsing)**: Document is being fetched and analyzed.
    - **Faint green**: Answers are ready to view.
    - **Faint red**: Informative error indicator.
  - **Hover-to-Reveal Answer Box**: An isolated Shadow DOM floating card (`max-width: 360px`, `max-height: 320px`, dark backdrop-blur) that is completely invisible (`opacity: 0`, `pointer-events: none`) until you move your cursor into the bottom-left corner.
  - **Immediate Hide on Exit**: Moving your cursor away instantly restores zero visibility (`opacity: 0`, pointer-events disabled) and shrinks the hit area back to `60px × 60px`.

- **Zero-Download Document Support**:
  - **Google Classroom & Google Drive In-Memory Extraction**: Works directly on Google Classroom preview pages (`classroom.google.com/...`) and Google Drive previews without requiring you to download any file to disk. It automatically discovers the underlying document ID and fetches the stream in-memory using your existing Google session.
  - **Direct PDF Support**: Works on local PDFs (`file:///C:/Users/.../document.pdf`) and online PDFs (`https://.../paper.pdf`).
  - **Multi-Strategy Fallback**: If raw binary retrieval is restricted, Harpocrates extracts the document's rendered text layers directly from the viewer DOM.

- **Dual AI Provider Support**:
  - **Google Gemini API (100% Free / Recommended)**:
    - Directly interfaces with Google AI Studio's `generativelanguage.googleapis.com` API.
    - Requires **$0 balance** (completely free tier with generous rate limits).
    - Default Model: `gemini-3.8-flash` (latest multimodal engine for high accuracy on text, diagrams, and math).
    - Other options: `gemini-3.6-flash`, `gemini-3-flash-preview`.
  - **OpenRouter API**:
    - Optional support for OpenRouter's multimodal models.
    - Note: OpenRouter requires a minimum $0.50 prepaid credit balance for processing file attachments.

- **Isolated Shadow DOM**:
  - Injected UI runs entirely inside an isolated `ShadowRoot`, shielding it from page-level CSS or PDF viewer styles.

---

## Installation & Setup Guide

### 1. Load the Extension into Chrome
1. Open Google Chrome and navigate to:
   ```text
   chrome://extensions/
   ```
2. Enable **Developer mode** using the toggle in the top-right corner.
3. Click the **Load unpacked** button in the top-left corner.
4. Select the `Harpocrates` project directory:
   ```text
   c:\Users\LENOVO\Desktop\Harpocrates
   ```
5. If already installed, click the **Reload (↻)** icon on the Harpocrates card to load the latest changes.

---

### 2. Configure Your Free Google Gemini API Key
1. Get a free API key at [aistudio.google.com/apikey](https://aistudio.google.com/apikey) (Takes 10 seconds, no credit card needed).
2. From `chrome://extensions/`, click **Details** on Harpocrates, then click **Extension options**.
3. Ensure **Google Gemini** is selected (it is the default) and the model is set to `gemini-3.8-flash`.
4. Paste your API key (`AIzaSy...`).
5. Click **Save Settings**.

---

### 3. (Optional for Local Files) Enable File URL Access
If you ever want to open downloaded local files (`file:///`), open `chrome://extensions/` &rarr; click **Details** on Harpocrates &rarr; enable **"Allow access to file URLs"**.

---

## Usage Instructions

### In Google Classroom or Google Drive (Zero-Download):
1. Open the assignment or material preview inside Google Classroom.
2. Press <kbd>Ctrl</kbd> + <kbd>Shift</kbd> + <kbd>X</kbd> (Mac: <kbd>Cmd</kbd> + <kbd>Shift</kbd> + <kbd>X</kbd>).
3. The status dot in the bottom-left corner will turn **amber** while the document is read in-memory.
4. When the dot turns **green**, hover your cursor into the bottom-left corner to reveal the answers!

### On Regular Web & Local PDFs:
1. Open any PDF in Chrome.
2. Press <kbd>Ctrl</kbd> + <kbd>Shift</kbd> + <kbd>X</kbd>.
3. Hover over the bottom-left corner once the status dot turns green.

---

## File Structure

```text
Harpocrates/
├── manifest.json       # Manifest V3 (no toolbar icon, options_ui, commands, host_permissions)
├── background.js       # Background service worker (in-memory document extraction & Gemini 3.8 Flash)
├── options.html        # Embedded settings page UI with Provider selector
├── options.css         # Minimal dark-mode stylesheet for settings
├── options.js          # Settings controller (storage persistence & provider switching)
├── icons/              # Extension icons (for chrome://extensions display)
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md           # Documentation and setup instructions
```
